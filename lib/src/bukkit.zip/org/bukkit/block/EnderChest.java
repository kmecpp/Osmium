package org.bukkit.block;

/**
 * Represents a captured state of an ender chest.
 */
public interface EnderChest extends BlockState { }
