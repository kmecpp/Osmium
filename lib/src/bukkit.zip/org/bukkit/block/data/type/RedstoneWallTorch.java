package org.bukkit.block.data.type;

import org.bukkit.block.data.Directional;
import org.bukkit.block.data.Lightable;

public interface RedstoneWallTorch extends Directional, Lightable {
}
