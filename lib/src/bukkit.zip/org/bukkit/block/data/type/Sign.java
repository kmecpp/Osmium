package org.bukkit.block.data.type;

import org.bukkit.block.data.Rotatable;
import org.bukkit.block.data.Waterlogged;

public interface Sign extends Rotatable, Waterlogged {
}
