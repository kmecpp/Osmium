package org.bukkit.block.data.type;

import org.bukkit.block.data.Ageable;
import org.bukkit.block.data.Directional;

public interface Cocoa extends Ageable, Directional {
}
